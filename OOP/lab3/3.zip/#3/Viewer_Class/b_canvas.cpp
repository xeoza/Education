#include "b_canvas.h"

B_Canvas::B_Canvas()
{

}
