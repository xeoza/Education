#include "memoryerrors.h"

E_Memory::E_Memory()
{

}
