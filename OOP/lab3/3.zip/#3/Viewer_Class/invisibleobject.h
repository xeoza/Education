#ifndef INVISIBLEOBJECT_H
#define INVISIBLEOBJECT_H


#include "b_object.h"
#include "invisiblemodification.h"

class InvisibleObject : public B_Object
{
public:
    virtual ~InvisibleObject(){}
};

#endif // INVISIBLEOBJECT_H
