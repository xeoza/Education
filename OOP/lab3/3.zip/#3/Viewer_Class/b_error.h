#ifndef B_ERROR_H
#define B_ERROR_H


class B_Error
{

public:
    virtual const char* info() = 0;
};

#endif // B_ERROR_H
