#include "b_command.h"

B_Command::B_Command()
{

}
