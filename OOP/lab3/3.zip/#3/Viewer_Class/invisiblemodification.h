#ifndef INVISIBLEMODIFICATION_H
#define INVISIBLEMODIFICATION_H

#include "b_modification.h"

class InvisibleModification : public B_Modification
{

public:
    virtual ~InvisibleModification() {}

};

#endif // INVISIBLEMODIFICATION_H
