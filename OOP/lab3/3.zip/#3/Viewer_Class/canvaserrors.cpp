#include "canvaserrors.h"

E_NoCanvas::E_NoCanvas()
{

}
