#ifndef B_MANAGER_H
#define B_MANAGER_H


class B_Manager
{
public:

    virtual ~B_Manager(){}
};

#endif // B_MANAGER_H
