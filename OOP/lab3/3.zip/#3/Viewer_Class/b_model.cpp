#include "b_model.h"

B_Model::B_Model()
{

}
