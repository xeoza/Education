#include "b_scene.h"

B_scene::B_scene()
{

}
