#include "b_error.h"

B_Error::B_Error()
{

}
