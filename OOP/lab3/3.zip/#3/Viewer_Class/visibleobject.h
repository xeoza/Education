#ifndef VISIBLEOBJECT_H
#define VISIBLEOBJECT_H

#include "b_object.h"


class VisibleObject : public B_Object
{

public:
    virtual ~VisibleObject(){}
};

#endif // VISIBLEOBJECT_H
