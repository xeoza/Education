#ifndef COMMANDCREATOR_H
#define COMMANDCREATOR_H


class CommandCreator
{
public:
    CommandCreator();
};

#endif // COMMANDCREATOR_H