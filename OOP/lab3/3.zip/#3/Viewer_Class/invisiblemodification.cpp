#include "invisiblemodification.h"

InvisibleModification::InvisibleModification()
{

}
