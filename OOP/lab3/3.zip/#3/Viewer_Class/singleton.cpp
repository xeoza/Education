#include "singleton.h"

Singleton::Singleton()
{

}
