#include "visiblemodification.h"


double VisibleModification::radiansToDegree(double delta)
{
    return (delta * M_PI) / 180.0;
}
