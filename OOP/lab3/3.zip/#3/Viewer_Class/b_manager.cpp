#include "b_manager.h"

B_Manager::B_Manager()
{

}
