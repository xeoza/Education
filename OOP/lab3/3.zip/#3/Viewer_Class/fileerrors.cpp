#include "fileerrors.h"

FileErrors::FileErrors()
{

}
