#include "b_painter.h"

B_Painter::B_Painter()
{

}
