#include "b_object.h"

B_Object::B_Object()
{

}
