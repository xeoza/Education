#include "sourcemanager.h"

SourceManager::SourceManager()
{
//
}
